# Fraction-Trainer Website
A simple html website to teach 5th graders how to calculate with fractions in a little trainer like quiz.

# TODO:
- Add taskgeneration
- Add input
- Bugfixes
- Clean code
